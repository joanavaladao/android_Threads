package com.valadao.joana.sortarray;

import android.app.ActivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static android.R.attr.data;


public class MainActivity extends AppCompatActivity {

    EditText enter1;
    EditText enter2;
    EditText enter3;
    EditText enter4;
    EditText enter5;

    EditText result1;
    EditText result2;
    EditText result3;
    EditText result4;
    EditText result5;

    TextView intermediate;

    Button btnAsync;
    Button btnThread;

    int[] userInput = new int[5];
    int[] output = new int[5];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        assignUserInterface();

        btnAsync = (Button) findViewById(R.id.button_sort_async);
        btnThread = (Button) findViewById(R.id.button_sort_thread);

        btnAsync.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnThread.setClickable(false);
                btnThread.setEnabled(false);

                intermediate.setText("");

                if (getUserInput()) {
//                    Toast.makeText(MainActivity.this, "Input ok", Toast.LENGTH_LONG).show();
                    SortAsync async = new SortAsync();
                    async.execute(userInput[0], userInput[1], userInput[2], userInput[3], userInput[4]);
                } else {
                    btnThread.setClickable(true);
                    btnThread.setEnabled(true);
                }
            }
        });

        btnThread.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnAsync.setClickable(false);
                btnAsync.setEnabled(false);

                intermediate.setText("");

                if (getUserInput()) {
//                    Toast.makeText(MainActivity.this, "Input ok", Toast.LENGTH_LONG).show();
                    executeThread();
                } else {
                    btnAsync.setClickable(true);
                    btnAsync.setEnabled(true);
                }
            }
        });

    }

    private void executeThread() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i <= 3; i++) {

                    for (int j = i + 1; j <= 4; j++) {

                        if (output[i] > output[j]) {
                            int element = output[i];
                            output[i] = output[j];
                            output[j] = element;

                            intermediate.post(new Runnable() {
                                @Override
                                public void run() {
                                    StringBuilder text = new StringBuilder(intermediate.getText().toString());

                                    if (!text.toString().isEmpty()){
                                        text.append("\n");
                                    }

                                    text.append(String.valueOf(output[0]) + ", " +
                                            String.valueOf(output[1]) + ", " +
                                            String.valueOf(output[2]) + ", " +
                                            String.valueOf(output[3]) + ", " +
                                            String.valueOf(output[4]));

                                    intermediate.setText(text);
                                }
                            });
                        }
                        SystemClock.sleep(200);
                    } // for - j
                } // for - i

             result1.post(new Runnable() {
                 @Override
                 public void run() {
                     result1.setText(String.valueOf(output[0]));
                     result2.setText(String.valueOf(output[1]));
                     result3.setText(String.valueOf(output[2]));
                     result4.setText(String.valueOf(output[3]));
                     result5.setText(String.valueOf(output[4]));

                     btnAsync.setClickable(true);
                     btnAsync.setEnabled(true);
                 }
             });
            }
        }).start();
    }

    private void assignUserInterface() {

        enter1 = (EditText) findViewById(R.id.enter_1);
        enter2 = (EditText) findViewById(R.id.enter_2);
        enter3 = (EditText) findViewById(R.id.enter_3);
        enter4 = (EditText) findViewById(R.id.enter_4);
        enter5 = (EditText) findViewById(R.id.enter_5);

        result1 = (EditText) findViewById(R.id.result_1);
        result2 = (EditText) findViewById(R.id.result_2);
        result3 = (EditText) findViewById(R.id.result_3);
        result4 = (EditText) findViewById(R.id.result_4);
        result5 = (EditText) findViewById(R.id.result_5);

        intermediate = (TextView) findViewById(R.id.intermediate);
    }

    private Boolean verifyInput() {

        // testing the user input
        if (enter1.getText().toString().isEmpty() ||
                enter2.getText().toString().isEmpty() ||
                enter3.getText().toString().isEmpty() ||
                enter4.getText().toString().isEmpty() ||
                enter5.getText().toString().isEmpty()) {
            return false;
        }

        return true;
    }

    private boolean getUserInput() {

        if (!verifyInput()) {
            Toast.makeText(MainActivity.this, "All the positions in the array must be filled. Please, verify your data input.",
                    Toast.LENGTH_LONG).show();
            return false;
        } else {
            userInput[0] = Integer.parseInt(enter1.getText().toString());
            userInput[1] = Integer.parseInt(enter2.getText().toString());
            userInput[2] = Integer.parseInt(enter3.getText().toString());
            userInput[3] = Integer.parseInt(enter4.getText().toString());
            userInput[4] = Integer.parseInt(enter5.getText().toString());

            for (int i=0; i< userInput.length; i++){
                output[i] = userInput[i];
            }
            return true;
        }
    }


    class SortAsync extends AsyncTask<Integer, Integer, Integer[]> {

        @Override
        protected Integer[] doInBackground(Integer... params) {


            for (int i = 0; i <= 3; i++) {

                for (int j = i + 1; j <= 4; j++) {

                    if (output[i] > output[j]) {
                        int element = output[i];
                        output[i] = output[j];
                        output[j] = element;
                        publishProgress(output[0], output[1], output[2], output[3], output[4]);
                    }
                    SystemClock.sleep(200);
                } // for - j
            } // for - i

            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);


            StringBuilder text = new StringBuilder(intermediate.getText().toString());

            if (!text.toString().isEmpty()){
                text.append("\n");
            }

            text.append(String.valueOf(values[0]) + ", " +
                    String.valueOf(values[1]) + ", " +
                    String.valueOf(values[2]) + ", " +
                    String.valueOf(values[3]) + ", " +
                    String.valueOf(values[4]));

            intermediate.setText(text);
        }

        @Override
        protected void onPostExecute(Integer[] integers) {
            result1.setText(String.valueOf(output[0]));
            result2.setText(String.valueOf(output[1]));
            result3.setText(String.valueOf(output[2]));
            result4.setText(String.valueOf(output[3]));
            result5.setText(String.valueOf(output[4]));

            btnThread.setClickable(true);
            btnThread.setEnabled(true);
        }
    }
}